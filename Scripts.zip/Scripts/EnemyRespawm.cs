using System.Collections;
using UnityEngine;

public class EnemyRespawn : MonoBehaviour
{
    public GameObject enemyPrefab;          // Prefab musuh tipe 1
    public GameObject enemyPrefab2;         // Prefab musuh tipe 2
    public Transform[] respawnPoints;       // Array lokasi respawn
    public Transform sun;                   // Objek matahari
    public float respawnDelayDay = 10f;     // Waktu jeda respawn di siang hari
    public float respawnDelayNight = 50f;   // Waktu jeda respawn di malam hari
    public float respawnCooldownDay = 10f;  // Cooldown respawn di siang hari
    public float respawnCooldownNight = 25f;// Cooldown respawn di malam hari

    private GameObject[] currentEnemies;    // Referensi musuh di setiap titik
    private bool[] isCooldownActive;        // Status cooldown tiap titik
    private bool isDaytime;                 // Status siang atau malam

    void Start()
    {
        // Inisialisasi array untuk referensi musuh dan cooldown
        currentEnemies = new GameObject[respawnPoints.Length];
        isCooldownActive = new bool[respawnPoints.Length];

        // Mulai respawn di setiap titik
        for (int i = 0; i < respawnPoints.Length; i++)
        {
            StartCoroutine(RespawnEnemyAtPoint(i));
        }
    }

    void Update()
    {
        UpdateDayNightStatus();
    }

    private void UpdateDayNightStatus()
    {
        // Matahari dianggap siang jika rotasi x >= 5 dan <= 90
        isDaytime = sun.eulerAngles.x >= 5 && sun.eulerAngles.x <= 90;
    }

    private IEnumerator RespawnEnemyAtPoint(int index)
    {
        while (true)
        {
            // Dapatkan delay dan cooldown sesuai waktu
            float currentRespawnDelay = isDaytime ? respawnDelayDay : respawnDelayNight;
            float currentRespawnCooldown = isDaytime ? respawnCooldownDay : respawnCooldownNight;

            // Jika tidak ada musuh di titik ini atau cooldown tidak aktif
            if (currentEnemies[index] == null && !isCooldownActive[index])
            {
                // Pilih prefab berdasarkan kondisi index
                GameObject selectedPrefab = SelectEnemyPrefab(index);

                // Spawn musuh
                currentEnemies[index] = Instantiate(selectedPrefab, respawnPoints[index].position, respawnPoints[index].rotation);

                // Mulai cooldown untuk titik ini
                StartCoroutine(StartCooldown(index, currentRespawnCooldown));
            }

            // Tunggu hingga waktu jeda berikutnya
            yield return new WaitForSeconds(currentRespawnDelay);
        }
    }

    private GameObject SelectEnemyPrefab(int index)
    {
        if (index < 2) // Posisi 1 dan 2
        {
            return Random.Range(0, 2) == 0 ? enemyPrefab : enemyPrefab2;
        }
        else if (index > 2) // Posisi 4 dan seterusnya
        {
            return enemyPrefab2;
        }
        else // Posisi 3
        {
            return enemyPrefab;
        }
    }

    private IEnumerator StartCooldown(int index, float cooldownDuration)
    {
        isCooldownActive[index] = true; // Aktifkan cooldown
        yield return new WaitForSeconds(cooldownDuration); // Tunggu waktu cooldown
        isCooldownActive[index] = false; // Nonaktifkan cooldown
    }
}
