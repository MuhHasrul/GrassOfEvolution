using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class NextEvo2 : MonoBehaviour
{
    public void NextGame() {
        SceneManager.LoadScene("Evo2");
    }
    public void ExitGame() {
        SceneManager.LoadScene("MainMenu");
    } 
    public void TryAgain()
    {
        FindObjectOfType<SceneManagerHelper>().ReloadCurrentScene();
    }

}
