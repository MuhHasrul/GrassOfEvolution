using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PauseMenu : MonoBehaviour
{
    public GameObject pauseMenuPanel; // Panel pause menu
    private bool isPaused = false;    // Status game dijeda

    void Update()
    {
        // Periksa input untuk menampilkan/menyembunyikan pause menu
        if (Input.GetKeyDown(KeyCode.Escape) || Input.GetKeyDown(KeyCode.P))
        {
            if (isPaused)
            {
                ResumeGame();
            }
            else
            {
                PauseGame();
            }
        }
    }

    public void PauseGame()
    {
        pauseMenuPanel.SetActive(true); // Tampilkan menu pause
        Time.timeScale = 0f;           // Jeda waktu dalam game
        isPaused = true;
    }

    public void ResumeGame()
    {
        pauseMenuPanel.SetActive(false); // Sembunyikan menu pause
        Time.timeScale = 1f;             // Waktu kembali normal
        isPaused = false;
    }

    public void ExitGame()
    {
        // Kembalikan waktu normal sebelum keluar
        Time.timeScale = 1f;

        // Log untuk debugging di editor
        Debug.Log("Kembali ke main menu");

        // Keluar dari aplikasi (hanya berlaku di build)
        SceneManager.LoadScene("MainMenu");
    }

    public void SaveGame()
    {
        // Simpan data game (sesuaikan dengan mekanisme save game Anda)
        Debug.Log("Data game disimpan!");

        // Tambahkan logika penyimpanan data game di sini
        // Contoh: PlayerPrefs, file JSON, atau sistem save lainnya
    }
}
