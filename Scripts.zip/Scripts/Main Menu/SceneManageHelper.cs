using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneManagerHelper : MonoBehaviour
{
    private static SceneManagerHelper instance;
    private HealthBar healthBar;

    // Singleton pattern untuk memastikan hanya satu instance yang ada
    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject); // Membuat objek tetap ada di semua scene
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void Start()
    {
        // Coba cari komponen HealthBar di scene saat ini
        healthBar = FindObjectOfType<HealthBar>();
    }

    // Fungsi untuk memuat ulang scene
    public void ReloadCurrentScene()
    {
        string currentSceneName = SceneManager.GetActiveScene().name;
        StartCoroutine(ResetScene(currentSceneName));
    }

    // Fungsi untuk memuat scene lain
    public void LoadScene(string sceneName)
    {
        StartCoroutine(ResetScene(sceneName));
    }

    private IEnumerator ResetScene(string sceneName)
    {
        AsyncOperation asyncLoad = SceneManager.LoadSceneAsync(sceneName);
        while (!asyncLoad.isDone)
        {
            yield return null;
        }

        // Reset state setelah scene selesai dimuat
        OnSceneLoaded();
    }

    private void OnSceneLoaded()
    {
        healthBar = FindObjectOfType<HealthBar>(); // Cari HealthBar baru jika ada
        if (healthBar != null)
        {
            healthBar.UpdateStats(0, 0); // Reset HP/MP jika diperlukan
            Debug.Log("Scene berhasil dimuat ulang dan state di-reset.");
        }
    }
}
