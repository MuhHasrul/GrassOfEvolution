using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
    public GameObject optionsPanel;
    private bool isOptions = false;
    public void newGame() {
        SceneManager.LoadScene("Evo0");
    }
    public void continueGame() {

    }
    public void quitGame() {
        Application.Quit();
        Debug.Log("Quit Game");
    } 
    public void optionsMenu () {
        isOptions = !isOptions;
        optionsPanel.SetActive(isOptions);
    }
    public void backToMainMenu() {
        optionsPanel.SetActive(false);
        isOptions = false;
    }
}
