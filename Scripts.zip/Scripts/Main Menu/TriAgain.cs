using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro; // Pastikan TextMeshPro digunakan jika menggunakan TMP UI

public class TryAgain : MonoBehaviour
{
    [Header("UI Elements")]
    [SerializeField] private TextMeshProUGUI developmentMessageText; // Referensi ke UI Text untuk pesan

    public void tryAgain()
    {
        SceneManager.LoadScene("Evo2");
    }

    public void ExitGame()
    {
        SceneManager.LoadScene("MainMenu");
    }

    public void NextGame()
    {
        if (developmentMessageText != null)
        {
            developmentMessageText.gameObject.SetActive(true); // Tampilkan teks
            developmentMessageText.text = "Tunggu Pengembangan Selanjutnya";

            // Sembunyikan teks setelah beberapa detik
            StartCoroutine(HideMessageAfterDelay(3f)); // Sembunyikan setelah 3 detik
        }
        else
        {
            Debug.LogWarning("Development Message Text is not assigned!");
        }
    }

    private IEnumerator HideMessageAfterDelay(float delay)
    {
        yield return new WaitForSeconds(delay);
        if (developmentMessageText != null)
        {
            developmentMessageText.gameObject.SetActive(false); // Sembunyikan teks
        }
    }
}
