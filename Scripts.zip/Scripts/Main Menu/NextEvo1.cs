using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class NextEvo1 : MonoBehaviour
{
    public void NextGame() {
        SceneManager.LoadScene("Evo1");
    }
    public void ExitGame() {
        SceneManager.LoadScene("MainMenu");
    } 
    public void TryAgain() {
        SceneManager.LoadScene("Evo0");
    } 
}
