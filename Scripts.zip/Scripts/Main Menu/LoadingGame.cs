using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class LoadingGame : MonoBehaviour
{
    public Slider progressBar; // Referensi ke slider progress bar
    public Text loadingText; // Referensi ke teks yang menampilkan status loading
    public string sceneToLoad = "MainScene"; // Nama scene yang akan dimuat setelah loading selesai

    void Start()
    {
        // Mulai pemuatan data secara asinkron
        StartCoroutine(LoadData());
    }

    private IEnumerator LoadData()
    {
        // Misalkan ada beberapa proses untuk memuat data, 
        // kita akan mensimulasikan dengan delay

        // Mula-mula, set progress bar ke 0
        progressBar.value = 0;
        loadingText.text = "Memuat data...";

        // Simulasikan beberapa langkah pemuatan data
        yield return StartCoroutine(SimulateLoadingStep(0.2f, 0.2f));
        loadingText.text = "Memuat data karakter...";

        yield return StartCoroutine(SimulateLoadingStep(0.4f, 0.4f));
        loadingText.text = "Memuat data level...";

        yield return StartCoroutine(SimulateLoadingStep(0.6f, 0.6f));
        loadingText.text = "Memuat data inventory...";

        yield return StartCoroutine(SimulateLoadingStep(0.8f, 0.8f));

        // Setelah semua data dimuat, mulai scene utama
        loadingText.text = "Pemuatan selesai!";
        yield return new WaitForSeconds(1f); // Beri sedikit waktu agar teks selesai ditampilkan

        // Muat scene berikutnya
        SceneManager.LoadScene(sceneToLoad);
    }

    // Fungsi untuk mensimulasikan pemuatan data dengan delay tertentu
    private IEnumerator SimulateLoadingStep(float targetProgress, float delay)
    {
        float currentProgress = progressBar.value;
        while (currentProgress < targetProgress)
        {
            currentProgress += Time.deltaTime / delay;
            progressBar.value = Mathf.Clamp01(currentProgress);
            yield return null;
        }
    }
}
