using System.Collections;
using UnityEngine;

public class EnemyFadeOut : MonoBehaviour
{
    private Renderer enemyRenderer;
    private Color originalColor;
    private bool isDying = false;
    public float fadeDuration = 2f; // Durasi fade-out dalam detik

    void Start()
    {
        // Ambil Renderer dari objek untuk mengakses materialnya
        enemyRenderer = GetComponent<Renderer>();
        if (enemyRenderer != null && enemyRenderer.material != null)
        {
            string shaderName = enemyRenderer.material.shader.name;

            if (shaderName.Contains("Transparent") || shaderName.Contains("Fade"))
            {
                Debug.Log("Shader supports transparency: " + shaderName);
            }
            else
            {
                Debug.Log("Shader does not support transparency: " + shaderName);
            }
        }
        if (enemyRenderer != null)
        {
            originalColor = enemyRenderer.material.color;
        }
    }

    public void Die()
    {
        if (!isDying)
        {
            isDying = true;
            StartCoroutine(FadeOutAndDestroy());
        }
    }

    private IEnumerator FadeOutAndDestroy()
    {
        if (enemyRenderer == null)
            yield break;

        float elapsedTime = 0f;

        // Lakukan fade-out
        while (elapsedTime < fadeDuration)
        {
            elapsedTime += Time.deltaTime;
            float alpha = Mathf.Lerp(1f, 0f, elapsedTime / fadeDuration); // Mengurangi alpha secara bertahap
            Color newColor = originalColor;
            newColor.a = alpha; // Tetapkan nilai alpha baru
            enemyRenderer.material.color = newColor;

            yield return null; // Tunggu frame berikutnya
        }

        // Hapus objek setelah fade-out selesai
        Destroy(gameObject, 2f);

    }
}
