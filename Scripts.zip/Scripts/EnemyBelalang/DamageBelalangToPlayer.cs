using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DamageBelalangToPlayer : MonoBehaviour
{
    public float damageAmount = 10f; // Nilai damage yang diberikan
    public float attackCooldown = 2f; // Waktu jeda antar serangan
    private bool canAttack = true; // Status apakah musuh dapat menyerang

    private EnemyBelalangAnimationController enemyAnim; // Referensi ke controller animasi
    private bool isAttacking = false; // Status apakah animasi serangan sedang dimainkan

    void Start()
    {
        // Mendapatkan referensi controller animasi
        enemyAnim = GetComponent<EnemyBelalangAnimationController>();
        if (enemyAnim == null)
        {
            Debug.LogError("EnemyJangkrikAnimationController tidak ditemukan pada " + gameObject.name);
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player") && canAttack && !isAttacking)
        {
            ApplyDamageToPlayer(other.gameObject);
        }
    }

    private void OnTriggerStay(Collider other)
    {
        if (other.CompareTag("Player") && canAttack && !isAttacking)
        {
            ApplyDamageToPlayer(other.gameObject);
        }
    }

    private void ApplyDamageToPlayer(GameObject player)
    {
        // Memulai animasi serangan
        if (enemyAnim != null)
        {
            isAttacking = true; // Set status serangan menjadi true
            enemyAnim.SetPunchAttackAnimation(true); // Memulai animasi serangan
            StartCoroutine(ResetAttackAnimation()); // Reset animasi setelah selesai
        }

        // Dapatkan komponen HealthBar pada pemain
        HealthBar playerHealth = player.GetComponent<HealthBar>();
        if (playerHealth != null)
        {
            playerHealth.TakeDamage(damageAmount); // Berikan damage ke pemain
            Debug.Log($"Pemain terkena damage: {damageAmount}");
        }

        // Mulai cooldown serangan
        StartCoroutine(AttackCooldown());
    }

    private IEnumerator ResetAttackAnimation()
    {
        yield return new WaitForSeconds(0.5f); // Durasi animasi serangan
        if (enemyAnim != null)
        {
            enemyAnim.SetPunchAttackAnimation(false); // Menghentikan animasi serangan
        }

        // Reset status serangan
        isAttacking = false;
    }

    private IEnumerator AttackCooldown()
    {
        canAttack = false; // Nonaktifkan serangan selama cooldown
        yield return new WaitForSeconds(attackCooldown);
        canAttack = true; // Aktifkan kembali serangan
    }
}
