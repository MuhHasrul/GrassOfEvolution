using System.Collections;
using UnityEngine;
using UnityEngine.AI;

public class EnemyBelalangControler : MonoBehaviour
{
    private EnemyBelalangAnimationController enemyAnim; // Controller animasi musuh
    private NavMeshAgent agent;                         // Komponen NavMeshAgent
    public Transform player;                            // Referensi ke pemain
    public float attackRange = 5f;                      // Jarak untuk menyerang
    public float runRange = 10f;                        // Jarak untuk berlari
    public float walkRange = 30f;                       // Jarak untuk berjalan

    private int attackCount = 0;                        // Counter serangan

    void Start()
    {
        // Inisialisasi NavMeshAgent
        agent = GetComponent<NavMeshAgent>();
        if (agent == null)
        {
            Debug.LogError("NavMeshAgent tidak ditemukan pada " + gameObject.name);
        }

        // Inisialisasi controller animasi
        enemyAnim = GetComponent<EnemyBelalangAnimationController>();
        if (enemyAnim == null)
        {
            Debug.LogError("EnemyBelalangAnimationController tidak ditemukan pada " + gameObject.name);
        }

        // Validasi referensi pemain
        if (player == null)
        {
            Debug.LogError("Player Transform belum diatur pada " + gameObject.name);
        }
    }

    void Update()
    {
        if (agent == null || !agent.isOnNavMesh || player == null) return;

        float distanceToPlayer = Vector3.Distance(transform.position, player.position);

        if (distanceToPlayer > attackRange)
        {
            // Mengatur destinasi NavMesh ke posisi pemain jika belum diatur
            if (agent.destination != player.position)
            {
                agent.SetDestination(player.position);
            }

            // Logika animasi berdasarkan jarak ke pemain
            if (distanceToPlayer > walkRange)
            {
                SetEnemyState(true, false, false, false);
            }
            else if (distanceToPlayer > runRange)
            {
                SetEnemyState(false, true, false, false);
            }
            else
            {
                SetEnemyState(false, false, true, false);
            }
        }
        else
        {
            // Jika dalam jarak serangan, berhenti dan serang
            agent.SetDestination(transform.position);
            attackCount++;

            if (attackCount >= 5)
            {
                attackCount = 0;
                SetEnemyState(false, false, false, true); // Animasi Swim Attack
            }
            else
            {
                SetEnemyState(false, false, false, false); // Animasi Punch Attack
                enemyAnim.SetPunchAttackAnimation(true);
            }
        }
    }

    /// <summary>
    /// Mengatur status animasi musuh.
    /// </summary>
    /// <param name="isWalking">Apakah musuh sedang berjalan?</param>
    /// <param name="isRunning">Apakah musuh sedang berlari?</param>
    /// <param name="isJumpAttacking">Apakah musuh sedang melompat menyerang?</param>
    /// <param name="isSwimmingAttack">Apakah musuh sedang menyerang dengan berenang?</param>
    private void SetEnemyState(bool isWalking, bool isRunning, bool isJumpAttacking, bool isSwimmingAttack)
    {
        enemyAnim.SetWalkingAnimation(isWalking);
        enemyAnim.SetRunningAnimation(isRunning);
        enemyAnim.SetJumpAttackAnimation(isJumpAttacking);
        enemyAnim.SetSwimAttackAnimation(isSwimmingAttack);
    }
}
