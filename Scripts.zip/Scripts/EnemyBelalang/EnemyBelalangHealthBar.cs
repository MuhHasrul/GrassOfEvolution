using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.AI;

public class EnemyBelalangHealthBar : MonoBehaviour
{
    private EnemyBelalangAnimationController enemyAnim;
    private NavMeshAgent agent;
    private Animator animator;

    public Transform player;
    public Slider healthSlider;
    public Slider easeHealthSlider;

    public float maxHealth = 100f;
    public float health;
    public float lerpSpeed = 5f;

    private float normalSpeed;
    private bool isTakingDamage = false;
    private bool hasGivenExp = false; // To check if experience has been awarded

    private Vector3 spawnPosition;
    private int expAmount; // Amount of EXP to be given

    void Start()
    {
        // Initialize components
        agent = GetComponent<NavMeshAgent>();
        animator = GetComponent<Animator>();
        enemyAnim = GetComponent<EnemyBelalangAnimationController>();
        spawnPosition = transform.position;

        // Set initial health values
        health = maxHealth;
        expAmount = Mathf.RoundToInt(maxHealth * 0.5f); // Example: EXP = 50% of maxHealth

        // Set health sliders
        if (healthSlider != null)
        {
            healthSlider.maxValue = maxHealth;
            healthSlider.value = health;
        }

        if (easeHealthSlider != null)
        {
            easeHealthSlider.maxValue = maxHealth;
            easeHealthSlider.value = health;
        }

        // Store normal speed
        if (agent != null)
            normalSpeed = agent.speed;
    }

    void Update()
    {
        // Normal movement if not taking damage
        if (!isTakingDamage && agent != null && agent.isOnNavMesh && player != null)
        {
            agent.SetDestination(player.position);
        }

        // Sync health sliders
        if (healthSlider.value != health)
        {
            healthSlider.value = health;
        }

        if (easeHealthSlider.value != healthSlider.value)
        {
            easeHealthSlider.value = Mathf.Lerp(easeHealthSlider.value, health, lerpSpeed * Time.deltaTime);
        }
    }

    public void TakeDamage(float damage)
    {
        if (health <= 0) return;

        health -= damage;
        health = Mathf.Clamp(health, 0, maxHealth);

        if (health > 0)
        {
            // Trigger damage animation
            if (enemyAnim != null)
                enemyAnim.TriggerTakeDamageAnimation();

            StartCoroutine(StopMovementForImpact());
        }
        else if (health <= 0 && !hasGivenExp) // Give EXP if not already given
        {
            if (enemyAnim != null)
            {
                // Trigger death animations
                if (Random.Range(0, 2) == 0)
                    enemyAnim.TriggerDieImpactAnimation();
                else
                    enemyAnim.TriggerDieShotAnimation();

                // Start respawn logic after death
                StartCoroutine(DisableOnDie());
            }
            GiveExperience(); // Award EXP to the player
        }
    }

    private void GiveExperience()
    {
        if (ExperienceManager.Instance != null)
        {
            ExperienceManager.Instance.AddExperience(expAmount);
            Debug.Log($"Player gained {expAmount} EXP from defeating the enemy!");
        }
        hasGivenExp = true; // Mark that EXP has been given
    }

    private IEnumerator DisableOnDie()
    {
        yield return new WaitForSeconds(3f); // Wait for death animation to finish
        gameObject.SetActive(false); // Deactivate enemy

        // Wait before respawning
        yield return new WaitForSeconds(1f);
        gameObject.SetActive(true); // Reactivate enemy
        transform.position = spawnPosition; // Reset position
        agent.SetDestination(player.position); // Start moving towards player again
    }

    private IEnumerator StopMovementForImpact()
    {
        // Stop movement temporarily during damage
        isTakingDamage = true;

        if (agent != null)
            agent.speed = 0;

        // Wait for damage animation duration
        if (animator != null)
        {
            float animLength = animator.GetCurrentAnimatorStateInfo(0).length;
            yield return new WaitForSeconds(animLength);
        }

        // Resume movement
        if (agent != null)
            agent.speed = normalSpeed;

        isTakingDamage = false;
    }
}
