using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.AI;

public class EnemyJangkrikHealthBar : MonoBehaviour
{
    private EnemyJangkrikAnimationController enemyAnim;
    private NavMeshAgent agent;
    private Animator animator;

    public Transform player;
    public Slider healthSlider;
    public Slider easeHealthSlider;

    public float maxHealth = 50f;
    public float health;
    public float lerpSpeed = 5f;

    private float normalSpeed;
    private bool isTakingDamage = false;
    private bool hasGivenExp = false; // Menandai apakah EXP sudah diberikan

    private Vector3 spawnPosition;
    int expAmount; // Jumlah EXP yang diberikan

    void Start()
    {
        // Inisialisasi komponen
        agent = GetComponent<NavMeshAgent>();
        animator = GetComponent<Animator>();
        enemyAnim = GetComponent<EnemyJangkrikAnimationController>();
        spawnPosition = transform.position;

        // Set nilai awal health
        health = maxHealth;
        expAmount = Mathf.RoundToInt(maxHealth * 1f); // Hitung EXP berdasarkan maxHealth
        if (healthSlider != null)
        {
            healthSlider.maxValue = maxHealth;
            healthSlider.value = health;
        }
        if (easeHealthSlider != null)
        {
            easeHealthSlider.maxValue = maxHealth;
            easeHealthSlider.value = health;
        }

        // Simpan kecepatan normal
        if (agent != null)
            normalSpeed = agent.speed;
    }

    void Update()
    {
        // Jalankan logika pergerakan normal jika tidak terkena damage
        if (!isTakingDamage && agent != null && agent.isOnNavMesh && player != null)
        {
            agent.SetDestination(player.position);
        }

        // Sinkronisasi slider health
        if (healthSlider.value != health)
        {
            healthSlider.value = health;
        }

        if (healthSlider.value != easeHealthSlider.value)
        {
            easeHealthSlider.value = Mathf.Lerp(easeHealthSlider.value, health, lerpSpeed * Time.deltaTime);
        }
    }

    public void TakeDamage(float damage)
    {
        if (health <= 0) return;

        health -= damage;
        health = Mathf.Clamp(health, 0, maxHealth);

        if (health > 0)
        {
            // Trigger animasi damage
            if (enemyAnim != null)
                enemyAnim.TriggerTakeDamageAnimation();

            StartCoroutine(StopMovementForImpact());
        }
        else if (health <= 0 && !hasGivenExp) // Berikan EXP jika belum diberikan
        {
            if (enemyAnim != null)
            {
                enemyAnim.TriggerDieImpactAnimation();
            }

            GiveExperience(); // Berikan EXP kepada pemain
            Destroy(gameObject, 3f); // Hancurkan musuh setelah animasi selesai
        }
    }

    private void GiveExperience()
    {
        if (ExperienceManager.Instance != null)
        {
            ExperienceManager.Instance.AddExperience(expAmount);
            Debug.Log($"Player gained {expAmount} EXP from defeating the enemy!");
        }
        hasGivenExp = true; // Tandai bahwa EXP sudah diberikan
    }

    private IEnumerator StopMovementForImpact()
    {
        // Hentikan pergerakan sementara
        isTakingDamage = true;

        if (agent != null)
            agent.speed = 0;

        // Tunggu durasi animasi damage
        if (animator != null)
        {
            float animLength = animator.GetCurrentAnimatorStateInfo(0).length;
            yield return new WaitForSeconds(animLength);
        }

        // Lanjutkan pergerakan
        if (agent != null)
            agent.speed = normalSpeed;

        isTakingDamage = false;
    }
    
}
