using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.AI;
public class EnemyJangkrikControler : MonoBehaviour
{
    private EnemyJangkrikAnimationController enemyAnim;
    private NavMeshAgent agent;
    public Transform player;
    public float attackRange = 5f;
    public float walkRange = 30f;

    void Start()
    {
        agent = GetComponent<NavMeshAgent>();
        if (agent == null)
        {
            Debug.LogError("NavMeshAgent tidak ditemukan pada " + gameObject.name);
        }

        enemyAnim = GetComponent<EnemyJangkrikAnimationController>();
        if (enemyAnim == null)
        {
            Debug.LogError("EnemyBelalangAnimationController tidak ditemukan pada " + gameObject.name);
        }

        if (player == null)
        {
            Debug.LogError("Player Transform belum diatur pada " + gameObject.name);
        }
    }

    void Update()
    {
        if (agent == null || !agent.isOnNavMesh || player == null) return;

        float distanceToPlayer = Vector3.Distance(transform.position, player.position);

        if (distanceToPlayer > attackRange)
        {
            if (agent.destination != player.position)
            {
                agent.SetDestination(player.position);
            }

            enemyAnim.SetWalkingAnimation(true);

        }
        else
        {
            enemyAnim.SetWalkingAnimation(false);
            agent.SetDestination(transform.position);
            enemyAnim.SetPunchAttackAnimation(true);
        }
    }
}


