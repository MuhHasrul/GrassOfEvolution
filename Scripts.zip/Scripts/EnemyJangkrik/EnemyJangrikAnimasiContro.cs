using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.AI;
public class EnemyJangkrikAnimationController : MonoBehaviour
{
    private Animator animator;

    void Start()
    {
        animator = GetComponent<Animator>();
    }

    public void SetWalkingAnimation(bool isWalking)
    {
        animator.SetBool("isWalking", isWalking);
    }
    public void SetPunchAttackAnimation(bool isPunchAttack)
    {
        animator.SetBool("isPunchAttack", isPunchAttack);
    }
    public void TriggerTakeDamageAnimation()
    {
        animator.SetTrigger("TakeDamage");
    }
    public void TriggerDieImpactAnimation()
    {
        animator.SetTrigger("DieImpact");
    }
    public void TriggerVictoryAnimation()
    {
        animator.SetTrigger("Victory");
    }
        
}