using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraLock : MonoBehaviour
{
    public Transform cameraTarget;
    void Update()
    {
        transform.LookAt(cameraTarget.position);
    }
}
