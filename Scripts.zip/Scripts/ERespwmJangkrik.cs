using System.Collections;
using UnityEngine;

public class ERespawnJangkrik : MonoBehaviour
{
    public GameObject enemyPrefab;          // Prefab musuh
    public Transform respawnPoint;          // Lokasi respawn
    public Transform sun;                   // Objek matahari
    public float respawnDelayDay = 10f;     // Waktu jeda respawn musuh di siang hari
    public float respawnDelayNight = 50f;   // Waktu jeda respawn musuh di malam hari
    public float respawnCooldownDay = 10f;  // Cooldown respawn di siang hari
    public float respawnCooldownNight = 25f; // Cooldown respawn di malam hari

    private GameObject currentEnemy;        // Referensi ke musuh saat ini
    private bool isCooldownActive = false;  // Status apakah cooldown aktif
    private bool isDaytime;                 // Status siang atau malam

    void Start()
    {
        StartCoroutine(RespawnEnemy());
    }

    void Update()
    {
        UpdateDayNightStatus();
    }

    private void UpdateDayNightStatus()
    {
        // Matahari dianggap terbit jika rotasi x > 0
        isDaytime = sun.eulerAngles.x>= 5 && sun.eulerAngles.x <= 90;
    }

    private IEnumerator RespawnEnemy()
    {
        while (true)
        {
            float currentRespawnDelay = isDaytime ? respawnDelayDay : respawnDelayNight;
            float currentRespawnCooldown = isDaytime ? respawnCooldownDay : respawnCooldownNight;

            // Jika tidak ada musuh atau musuh telah dihancurkan, dan cooldown tidak aktif
            if (currentEnemy == null || !isCooldownActive)
            {
                // Spawn musuh di lokasi respawn
                currentEnemy = Instantiate(enemyPrefab, respawnPoint.position, respawnPoint.rotation);

                // Mulai cooldown setelah respawn
                StartCoroutine(StartCooldown(currentRespawnCooldown));
            }

            // Tunggu waktu jeda sebelum memeriksa ulang
            yield return new WaitForSeconds(currentRespawnDelay);
        }
    }

    private IEnumerator StartCooldown(float cooldownDuration)
    {
        isCooldownActive = true; // Aktifkan cooldown
        yield return new WaitForSeconds(cooldownDuration); // Tunggu waktu cooldown
        isCooldownActive = false; // Nonaktifkan cooldown
    }
}
