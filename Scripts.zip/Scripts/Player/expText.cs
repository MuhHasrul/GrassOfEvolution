using UnityEngine;

public class ExpTest : MonoBehaviour
{
    public Transform Sun;
    public float experiencePerSecond = 100f;

    private float timer = 0f; // Variabel untuk melacak waktu yang berlalu

    void Update()
    {
        if (Sun == null)
        {
            Debug.LogWarning("Sun transform is not assigned!");
            return;
        }

        // Cek apakah rotasi sumbu X matahari berada di antara 5 dan 90 derajat
        if (Sun.eulerAngles.x >= 5 && Sun.eulerAngles.x <= 90)
        {
            timer += Time.deltaTime; // Tambahkan waktu yang berlalu pada setiap frame

            if (timer >= 1f) // Jika sudah mencapai 1 detik
            {
                int experienceToAdd = Mathf.RoundToInt(experiencePerSecond);
                if (ExperienceManager.Instance != null)
                {
                    ExperienceManager.Instance.AddExperience(experienceToAdd);
                }
                else
                {
                    Debug.LogWarning("ExperienceManager.Instance is null!");
                }

                timer -= 1f; // Kurangi timer untuk mengakomodasi sisa waktu
            }
        }
    }
}
