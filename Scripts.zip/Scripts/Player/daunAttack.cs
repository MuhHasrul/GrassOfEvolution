using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DaunAttack : MonoBehaviour
{
    public float damage = 10f; // Damage yang diberikan daun
    public float life = 3f;   // Waktu hidup daun sebelum hancur

    void Awake()
    {   
        // Hancurkan objek ini setelah durasi tertentu
        // Destroy(gameObject);
    }

    void OnCollisionEnter(Collision collision)
    {
        // Cek apakah objek yang ditabrak memiliki salah satu komponen kesehatan
        var enemyHealthJangkrik = collision.gameObject.GetComponent<EnemyJangkrikHealthBar>();
        var enemyHealthBelalang = collision.gameObject.GetComponent<EnemyBelalangHealthBar>();

        if (enemyHealthJangkrik != null)
        {
            // Berikan damage ke EnemyJangkrik
            enemyHealthJangkrik.TakeDamage(damage);
        }
        else if (enemyHealthBelalang != null)
        {
            // Berikan damage ke EnemyBelalang
            enemyHealthBelalang.TakeDamage(damage);
        }

        // Hancurkan daun setelah menabrak
        Destroy(gameObject);
    }
}
