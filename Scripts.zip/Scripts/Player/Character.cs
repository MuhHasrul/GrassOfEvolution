// // using System.Collections;
// // using System.Collections.Generic;
// // using UnityEngine;

// // public class Character : MonoBehaviour
// // {
// //     [SerializeField] int currentHealth, maxHealth, currentExperience, maxExperience, currentLevel;

// //     private void OnEnable()
// //     {
// //         ExperienceManager.Instance.OnExperienceChanged += HandleExperienceChanged;
// //     }
// //     private void OnDisable()
// //     {
// //         ExperienceManager.Instance.OnExperienceChanged -= HandleExperienceChanged;
// //     }

// //     private void HandleExperienceChanged(int newExperience)
// //     {
// //         currentExperience += newExperience;
// //         if (currentExperience >= maxExperience)
// //         {
// //             LevelUp();
// //         }
// //     }
// //     private void LevelUp()
// //     {
// //         maxHealth += maxHealth * 5%;
// //         currentHealth = maxHealth;

// //         currentLevel++;
// //         currentExperience = 0;
// //         maxExperience += maxExperience * 10%;
// //     }
    
// // }


// using UnityEngine;

// public class Character : MonoBehaviour
// {
//     [SerializeField] private int currentHealth;
//     [SerializeField] private int maxHealth;
//     [SerializeField] private int currentExperience;
//     [SerializeField] private int maxExperience;
//     [SerializeField] private int currentLevel;

//     private void OnEnable()
//     {
//         if (ExperienceManager.Instance != null)
//         {
//             ExperienceManager.Instance.OnExperienceChanged += HandleExperienceChanged;
//         }
//         else
//         {
//             Debug.LogError("ExperienceManager instance is not found!");
//         }
//     }

//     private void OnDisable()
//     {
//         if (ExperienceManager.Instance != null)
//         {
//             ExperienceManager.Instance.OnExperienceChanged -= HandleExperienceChanged;
//         }
//     }

//     private void HandleExperienceChanged(int newExperience)
//     {
//         currentExperience += newExperience;

//         // Jika pengalaman saat ini melebihi batas maksimum, lakukan level up
//         while (currentExperience >= maxExperience)
//         {
//             currentExperience -= maxExperience;
//             LevelUp();
//         }
//     }

//     private void LevelUp()
//     {
//         // Tambahkan health maksimal sebesar 5% dan set health saat ini ke maksimal
//         maxHealth += Mathf.CeilToInt(maxHealth * 0.05f);
//         currentHealth = maxHealth;

//         // Naikkan level dan tingkatkan batas pengalaman
//         currentLevel++;
//         maxExperience += Mathf.CeilToInt(maxExperience * 0.10f);

//         Debug.Log($"Level Up! Current Level: {currentLevel}, Max Health: {maxHealth}, Max Experience: {maxExperience}");
//     }
// }
