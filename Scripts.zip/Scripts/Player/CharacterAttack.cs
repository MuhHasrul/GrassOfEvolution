using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class CharacterAttack : MonoBehaviour
{
    private CharakterAnimasi charakterAnim;
    private HealthBar healthBar;
    public Transform daunSpawnPoint;
    public GameObject daunPrefab;
    public float daunSpeed = 10f;
    public float rotationSpeed = 5f;
    public LayerMask enemyLayer;
    private Transform targetEnemy;
    public float recoilDmg = 10f;

    public Vector3 throwScale = new Vector3(0.1f, 0.1f, 0.1f);
    private bool isThrowing = false; // Untuk mencegah multiple attack selama delay

    public float attackRadius = 10f; // Jarak maksimal untuk bisa menyerang musuh
    public float delayDaun = 1f;

    void Start()
    {
        charakterAnim = GetComponent<CharakterAnimasi>();
        healthBar = GetComponent<HealthBar>();

        if (healthBar == null)
        {
            Debug.LogError("HealthBar tidak ditemukan pada GameObject ini!");
        }
    }

    void Update()
    {
        if (Input.GetMouseButtonDown(0)) // Klik kiri mouse
        {
            DetectEnemyUnderMouse();
        }

        if (targetEnemy != null)
        {
            // Pastikan musuh berada dalam jangkauan serangan
            if (Vector3.Distance(transform.position, targetEnemy.position) <= attackRadius)
            {
                FaceTarget();

                if (Input.GetMouseButtonDown(0) && !isThrowing) // Klik kiri untuk menyerang
                {
                    StartCoroutine(ThrowLeafWithDelay(delayDaun)); // Delay 1 detik sebelum melempar daun
                }
            }
            else
            {
                Debug.LogWarning($"Target terlalu jauh! Jaraknya lebih dari {attackRadius}.");
            }
        }
    }

    private void DetectEnemyUnderMouse()
    {
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        RaycastHit hit;

        if (Physics.Raycast(ray, out hit, Mathf.Infinity, enemyLayer))
        {
            targetEnemy = hit.transform;
            Debug.Log($"Musuh {targetEnemy.name} ditargetkan!");
        }
        else
        {
            Debug.LogWarning("Tidak ada musuh yang diklik!");
            targetEnemy = null;
        }
    }

    private void FaceTarget()
    {
        if (targetEnemy == null) return;

        Vector3 direction = targetEnemy.position - transform.position;
        direction.y = 0;
        Quaternion targetRotation = Quaternion.LookRotation(direction);
        transform.rotation = Quaternion.Slerp(transform.rotation, targetRotation, Time.deltaTime * rotationSpeed);
    }

    private IEnumerator ThrowLeafWithDelay(float delay)
    {
        isThrowing = true;

        // Trigger animasi serangan
        PerformAttack();

        // Tunggu selama delay
        yield return new WaitForSeconds(delay);

        // Spawn daun
        var daun = Instantiate(daunPrefab, daunSpawnPoint.position, Quaternion.identity);
        Vector3 directionToTarget = (targetEnemy.position - daunSpawnPoint.position).normalized;
        daun.transform.rotation = Quaternion.LookRotation(directionToTarget);
        daun.transform.localScale = throwScale;

        Rigidbody rb = daun.GetComponent<Rigidbody>();
        if (rb != null)
        {
            rb.velocity = directionToTarget * daunSpeed;
        }

        isThrowing = false;
    }

    private void PerformAttack()
    {
        if (targetEnemy == null) return;

        if (charakterAnim != null)
        {
            // Kurangi health menggunakan HealthBar
            if (healthBar != null)
            {
                if (healthBar.health >= recoilDmg)
                {
                    charakterAnim.TriggerAttack();
                    healthBar.isInCombat = true;
                    healthBar.health -= recoilDmg;
                    Debug.Log($"Healt tersisa: {healthBar.health}");
                }
                else
                {
                    Debug.LogWarning("Tidak cukup health untuk menyerang!");
                    return;
                }
            }
        }

        

        Debug.Log($"Menyerang musuh {targetEnemy.name}!");
    }
}
