using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class ExpUIManager : MonoBehaviour
{
    [Header("UI Elements")]
    [SerializeField] private TextMeshProUGUI levelText;
    [SerializeField] private TextMeshProUGUI expText;
    public Slider expBar;

    private int previousLevelExp = 0;

    private void OnEnable()
    {
        if (ExperienceManager.Instance != null)
        {
            ExperienceManager.Instance.OnExperienceChanged += UpdateUI;
        }
    }

    private void OnDisable()
    {
        if (ExperienceManager.Instance != null)
        {
            ExperienceManager.Instance.OnExperienceChanged -= UpdateUI;
        }
    }

    private void UpdateUI(int currentExp, int currentLevel, int requiredExp)
    {
        // EXP saat ini untuk level saat ini
        int currentLevelExp = currentExp - previousLevelExp;

        // Sinkronkan teks level dan EXP
        levelText.text = $"Level {currentLevel}";
        expText.text = $"{currentLevelExp} / {requiredExp} EXP";

        // Sinkronkan progress bar
        expBar.value = Mathf.Clamp01((float)currentLevelExp / requiredExp);

        // Perbarui nilai previousLevelExp
        if (currentLevelExp >= requiredExp)
        {
            previousLevelExp += requiredExp;
        }
    }



}
