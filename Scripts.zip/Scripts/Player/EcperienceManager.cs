using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class ExperienceManager : MonoBehaviour
{
    public static ExperienceManager Instance;

    public delegate void ExperienceChangedHandler(int currentExp, int currentLevel, int nextLevelExp);
    public event ExperienceChangedHandler OnExperienceChanged;

    [Header("Experience Settings")]
    [SerializeField] private AnimationCurve expCurve;

    [Header("UI Elements")]
    [SerializeField] private TextMeshProUGUI levelText;
    [SerializeField] private TextMeshProUGUI expText;
    [SerializeField] private Slider expBar;
    [SerializeField] private GameObject specialLevelUIPanel; // UI khusus untuk level tertentu
    [SerializeField] private GameObject loseUIPanel; // UI untuk lose

    private bool isPaused = false; // Status game dijeda

    [Header("Stats Settings")]
    public float hpIncreasePerLevel = 5f; // Penambahan max HP per level
    public float mpIncreasePerLevel = 2.5f; // Penambahan max MP per level

    private int totalExp;
    private int currentLevel = 1;
    private int previousLevelExp = 0;

    private HealthBar healthBar; // Referensi ke HealthBar

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
        }
        else
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }

        healthBar = FindObjectOfType<HealthBar>();
        Debug.Log("ExperienceManager initialized!");
    }

    private void Update()
    {
        if (healthBar != null)
        {
            CheckHealth();
        }
    }

    private void CheckHealth()
    {
        if (healthBar.health <= 0 && !isPaused)
        {
            Time.timeScale = 0f; // Jeda permainan
            isPaused = true;
            ShowLoseUI();
        }
    }

    private void ShowLoseUI()
    {
        if (loseUIPanel != null)
        {
            loseUIPanel.SetActive(true); // Tampilkan UI *lose*
            Debug.Log("Player lost! Lose UI shown.");
        }
        else
        {
            Debug.LogWarning("Lose UI Panel is not assigned.");
        }
    }

    private void OnEnable()
    {
        OnExperienceChanged += UpdateUI;
    }

    private void OnDisable()
    {
        OnExperienceChanged -= UpdateUI;
    }

    public void AddExperience(int amount)
    {
        if (amount <= 0)
        {
            Debug.LogWarning("Experience amount must be positive.");
            return;
        }

        totalExp += amount;
        CheckForLevelUp();
        NotifyExperienceChanged();
    }

    private void CheckForLevelUp()
    {
        if (expCurve == null)
        {
            Debug.LogError("expCurve is not assigned!");
            return;
        }

        int nextLevelExp = (int)expCurve.Evaluate(currentLevel);
        while (totalExp >= nextLevelExp)
        {
            currentLevel++;
            Debug.Log($"Level Up! Current Level: {currentLevel}");

            previousLevelExp = nextLevelExp;
            nextLevelExp = (int)expCurve.Evaluate(currentLevel + 1);

            if (healthBar != null)
            {
                healthBar.maxHealth += hpIncreasePerLevel;
                healthBar.health += hpIncreasePerLevel;
                healthBar.maxMana += mpIncreasePerLevel;
                healthBar.mana += mpIncreasePerLevel;

                healthBar.health = Mathf.Clamp(healthBar.health, 0, healthBar.maxHealth);
                healthBar.mana = Mathf.Clamp(healthBar.mana, 0, healthBar.maxMana);

                healthBar.healthSlider.maxValue = healthBar.maxHealth;
                healthBar.manaSlider.maxValue = healthBar.maxMana;

                healthBar.UpdateStats(hpIncreasePerLevel, mpIncreasePerLevel);
            }

            CheckForSpecialLevel();

            NotifyExperienceChanged();
        }
    }

    private void CheckForSpecialLevel()
    {
        if ((currentLevel == 3 ) || (currentLevel == 5 ) || currentLevel == 8)
        {
            Time.timeScale = 0f; 
            isPaused = true;
            ShowSpecialLevelUI();
        }
    }

    private void ShowSpecialLevelUI()
    {
        if (specialLevelUIPanel != null)
        {
            specialLevelUIPanel.SetActive(true); // Tampilkan UI
            Debug.Log($"Special Level UI shown for Level {currentLevel}");
        }
        else
        {
            Debug.LogWarning("Special Level UI Panel is not assigned.");
        }
    }

    private void NotifyExperienceChanged()
    {
        if (expCurve == null)
        {
            Debug.LogError("expCurve is not assigned!");
            return;
        }

        int previousLevelExp = (int)expCurve.Evaluate(currentLevel - 1);
        int nextLevelExp = (int)expCurve.Evaluate(currentLevel);
        OnExperienceChanged?.Invoke(totalExp, currentLevel, nextLevelExp - previousLevelExp);
    }

    private void UpdateUI(int currentExp, int currentLevel, int requiredExp)
    {
        int currentLevelExp = currentExp - previousLevelExp;

        levelText.text = $"Level {currentLevel}";
        expText.text = $"{currentLevelExp} / {requiredExp} EXP";
        expBar.maxValue = requiredExp;

        expBar.value = currentLevelExp;
    }
}
