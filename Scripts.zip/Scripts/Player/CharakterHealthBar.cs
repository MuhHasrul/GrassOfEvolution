using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class HealthBar : MonoBehaviour
{
    private SceneManagerHelper sceneManagerHelper;

    private CharakterAnimasi charAnim;
    public Slider healthSlider;
    public Slider easeHealthSlider;
    public Slider manaSlider;
    public Slider easeManaSlider;

    public float maxHealth = 100f;
    public float maxMana = 50f;

    public float health;
    public float mana;
    public float healAmount = 15f;

    private float lerpSpeed = 5f;

    public string enemyTag = "Enemy";
    public float regenDelay = 5f; // Waktu tunggu sebelum regenerasi dimulai
    public float regenAmountHP = 0.05f; // Persentase regenerasi HP saat idle
    public float regenAmountMP = 0.05f; // Persentase regenerasi MP saat idle

    private float lastActionTime; // Waktu terakhir serangan atau menerima damage
    public bool isInCombat = false; // Status apakah sedang bertempur

    void Start()
    {
        charAnim = GetComponent<CharakterAnimasi>();
        sceneManagerHelper = FindObjectOfType<SceneManagerHelper>();

        health = maxHealth;
        mana = maxMana;

        if (healthSlider != null)
        {
            healthSlider.maxValue = maxHealth;
            healthSlider.value = health;
        }
        if (easeHealthSlider != null)
        {
            easeHealthSlider.maxValue = maxHealth;
            easeHealthSlider.value = health;
        }
        if (manaSlider != null)
        {
            manaSlider.maxValue = maxMana;
            manaSlider.value = mana;
        }
        if (easeManaSlider != null)
        {
            easeManaSlider.maxValue = maxMana;
            easeManaSlider.value = mana;
        }
    }


    void Update()
    {
        // Sinkronisasi nilai slider utama dengan nilai HP
        if (healthSlider != null && healthSlider.value != health)
        {
            healthSlider.value = health;
        }

        // Animasi smooth bar pada slider easeHealthSlider
        if (easeHealthSlider != null && easeHealthSlider.value != health)
        {
            easeHealthSlider.value = Mathf.Lerp(easeHealthSlider.value, health, lerpSpeed * Time.deltaTime);
        }

        // Sinkronisasi nilai slider utama dengan nilai MP
        if (manaSlider != null && manaSlider.value != mana)
        {
            manaSlider.value = mana;
        }

        // Animasi smooth bar pada slider easeManaSlider
        if (easeManaSlider != null && easeManaSlider.value != mana)
        {
            easeManaSlider.value = Mathf.Lerp(easeManaSlider.value, mana, lerpSpeed * Time.deltaTime);
        }

        // Regenerasi jika tidak dalam pertarungan dan HP/MP belum penuh
        if (!isInCombat && Time.time - lastActionTime >= regenDelay && (health < maxHealth || mana < maxMana))
        {
            Regenerate();
        }

        // Simulasi penyembuhan ketika klik kanan
        if (Input.GetMouseButtonDown(1))
        {
            Heal(healAmount);
        }
    }

    // Metode untuk memberikan damage
    public void TakeDamage(float damage)
    {
        health -= damage;
        health = Mathf.Clamp(health, 0, maxHealth);
        lastActionTime = Time.time; // Perbarui waktu aksi
        isInCombat = true; // Tetapkan status sedang bertempur
        Debug.Log($"Karakter terkena damage: {damage}, sisa HP: {health}");
        StartCoroutine(EndCombatAfterDelay());
    }

    // Metode untuk menambahkan HP dan mengurangi MP
    public void Heal(float healAmount)
    {
        if (mana >= healAmount * 0.33f)
        {
            mana -= healAmount * 0.33f;
            health += healAmount;
            health = Mathf.Clamp(health, 0, maxHealth);
            mana = Mathf.Clamp(mana, 0, maxMana);
            lastActionTime = Time.time; // Perbarui waktu aksi
            isInCombat = true; // Tetapkan status sedang bertempur

            if (charAnim != null)
            {
                charAnim.TriggerHealing();
            }
        }
        else
        {
            Debug.Log("Tidak cukup mana untuk menyembuhkan!");
        }

        StartCoroutine(EndCombatAfterDelay());
    }

    // Regenerasi HP dan MP
    private void Regenerate()
    {
        if (health < maxHealth || mana < maxMana)
        {
            float regenHP = maxHealth * regenAmountHP * Time.deltaTime;
            float regenMP = maxMana * regenAmountMP * Time.deltaTime;

            health += regenHP;
            mana += regenMP;

            health = Mathf.Clamp(health, 0, maxHealth);
            mana = Mathf.Clamp(mana, 0, maxMana);

            Debug.Log($"Regenerasi: +{regenHP} HP, +{regenMP} MP");
        }
    }

    // Mengatur status tidak bertempur setelah beberapa waktu
    private IEnumerator EndCombatAfterDelay()
    {
        yield return new WaitForSeconds(regenDelay);
        isInCombat = false; // Tetapkan status tidak bertempur
    }

    // Deteksi serangan musuh dengan OnTriggerEnter
    private void OnTriggerEnter(Collider other)
    {
        // Cek apakah objek memiliki komponen DamageJangkrikToPlayer
        DamageJangkrikToPlayer damageToPlayerJangkrik = other.GetComponent<DamageJangkrikToPlayer>();
        if (damageToPlayerJangkrik != null)
        {
            float enemyDamage = damageToPlayerJangkrik.damageAmount;
            Debug.Log($"Terkena serangan dari Jangkrik dengan damage: {enemyDamage}!");
            TakeDamage(enemyDamage);
        }

        // Cek apakah objek memiliki komponen DamageBelalangToPlayer
        DamageBelalangToPlayer damageToPlayerBelalang = other.GetComponent<DamageBelalangToPlayer>();
        if (damageToPlayerBelalang != null)
        {
            float enemyDamage = damageToPlayerBelalang.damageAmount;
            Debug.Log($"Terkena serangan dari Belalang dengan damage: {enemyDamage}!");
            TakeDamage(enemyDamage);
        }
    }


    public void UpdateStats(float additionalHP, float additionalMP)
    {
        maxHealth += additionalHP;
        health = maxHealth; // Isi ulang HP penuh

        maxMana += additionalMP;
        mana = maxMana; // Isi ulang MP penuh

        // Sinkronisasi slider
        if (healthSlider != null) healthSlider.maxValue = maxHealth;
        if (manaSlider != null) manaSlider.maxValue = maxMana;
        if (easeHealthSlider != null) easeHealthSlider.maxValue = maxHealth;
        if (easeManaSlider != null) easeManaSlider.maxValue = maxMana;

        Debug.Log($"Stats diperbarui: Max HP: {maxHealth}, Max MP: {maxMana}");
    }
    public void RestartGame()
{
    if (sceneManagerHelper != null)
    {
        sceneManagerHelper.ReloadCurrentScene();
    }
    else
    {
        Debug.LogError("SceneManagerHelper tidak ditemukan!");
    }
}


    

}
